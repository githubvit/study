from conf import settings
from lib import common

logger=common.get_logger('xxx')



logger.debug('xxxxx')
