# from nb import m1,m2,m3

# # 绝对导入
# from nb.m1 import f1,f2
# from nb.m2 import f3,f4
# from nb.m3 import f5,f6
# from nb.p1.m4 import f7


# 相对导入
from .m1 import f1,f2
from .m2 import f3,f4
from .m3 import f5,f6
from .p1.m4 import f7