def f1():
    print('f1')


def f2():
    print('f2')