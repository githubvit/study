from .m1 import f1

def f3():
    print('f3')


def f4():
    print('f4')
    f1()

