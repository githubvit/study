
def f5():
    print('f5')


def f6():
    print('f6')
