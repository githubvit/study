# from nb.m1 import f1
from ..m1 import f1

def f7():
    print('f7')
    f1()