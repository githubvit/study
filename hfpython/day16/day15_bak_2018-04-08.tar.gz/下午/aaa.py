s='asdfsadfsadf你好'
with open('a.txt','wt',encoding='utf-8') as f:
    f.write(s)